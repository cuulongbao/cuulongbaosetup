jQuery.validator.addMethod("addphone", function(phone_number, element) {
    phone_number = phone_number.replace(/\s+/g, "");
    return this.optional(element)  || phone_number.length > 9 && 
    phone_number.match(/^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im);
}, "Please specify a valid phone number");

$("#usernameForm").validate({
	    rules: {
	    	name: "required",
	    	phone: {
				addphone: true			 
			}
	    },
	    messages: {
	    	name: {required:require_data_chat },
	    	phone: {
				addphone: require_data_chat
	    	}
		},
	    errorElement: 'span',
	    errorPlacement: function (error, element) {
	      error.addClass('invalid-feedback');
	      element.closest('.form-group').append(error);
	    },
	    highlight: function (element, errorClass, validClass) {
	      $(element).addClass('is-invalid');
	    },
	    unhighlight: function (element, errorClass, validClass) {
	      $(element).removeClass('is-invalid');
	    }
	});
function openForm() {
	document.getElementById("myForm").style.display = "block";
	document.getElementsByClassName("open-button")[0].style.display = "none";
}

function closeForm() {
	document.getElementById("myForm").style.display = "none";
	document.getElementsByClassName("open-button")[0].style.display = "block";
} 

window.onbeforeunload = function(e) {
       return "Are you sure";
    };
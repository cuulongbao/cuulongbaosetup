'use strict';
var chatPage = document.querySelector('#chat-page');
var messageForm = document.querySelector('#messageForm');
var messageInput = document.querySelector('#message');
var messageArea = document.querySelector('#messageArea');
var audio = new Audio('/plugins/chat/sound/alert.mp3');
const sendMessageEndpoint="/app/chat.sendMessage";


var colors = [
    '#2196F3', '#32c787', '#00BCD4', '#ff5652',
    '#ffc107', '#ff85af', '#FF9800', '#39bbb0'
];

function sendMessage(event) {
    var messageContent = messageInput.value.trim();

    if(messageContent && stompClient) {
        var chatMessage = {
            sender: username,
            content: messageInput.value,
			target: "admin",
            type: 'CHAT'
        };

        stompClient.send(sendMessageEndpoint, {}, JSON.stringify(chatMessage));
        messageInput.value = '';
    }
    event.preventDefault();
}


function onMessageReceived(payload) {
    var message = JSON.parse(payload.body);
    var messageElement = document.createElement('li');
	 console.log(JSON.stringify(payload));

    if(message.type === 'CHAT') {
		if(message.sender=="admin"){
			audio.play();
		}
		
        messageElement.classList.add('chat-message');
        var avatarElement = document.createElement('i');
        var avatarText = document.createTextNode(message.fullname[0]);
        avatarElement.appendChild(avatarText);
        avatarElement.style['background-color'] = getAvatarColor(message.fullname);
        messageElement.appendChild(avatarElement);
        var usernameElement = document.createElement('span');
        var usernameText = document.createTextNode(message.fullname +" "+getTime());
		usernameElement.appendChild(usernameText);
        messageElement.appendChild(usernameElement);
		var textElement = document.createElement('p');
		console.log("message.sender "+message.sender);
		
		var messageText = document.createTextNode(message.content);
		textElement.appendChild(messageText);
		if(message.sender=="admin"){
			textElement.style['color'] = "rgb(155,0,0)";
			usernameElement.style['color'] = "rgb(155,0,0)";
		}
		messageElement.appendChild(textElement);
		messageArea.appendChild(messageElement);
		messageArea.scrollTop = messageArea.scrollHeight;
    }else{
		if(message.type === 'JOIN') {
			var supportUser = document.querySelector("#supportUser");
			supportUser.innerText= message.content;
		}
	}
}

function getAvatarColor(messageSender) {
    var hash = 0;
    for (var i = 0; i < messageSender.length; i++) {
        hash = 31 * hash + messageSender.charCodeAt(i);
    }
    var index = Math.abs(hash % colors.length);
    return colors[index];
}

messageForm.addEventListener('submit', sendMessage, true)
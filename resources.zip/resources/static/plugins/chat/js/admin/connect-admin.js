'use strict';

var usernamePage = document.querySelector('#username-page');
var usernameForm = document.querySelector('#usernameForm');
var messageForm= document.querySelector('#messageForm');
var connectingElement = document.querySelector('.connecting');
var stompClient = null;
var username = null;
var targetVal =null;
var phoneVal=null;
var userMap=new Map();
if(chatDomain ==undefined){
	var chatDomain ="";
}
var headers={};
if(chatDomain!="" && chatDomain.indexOf("localhost")!=-1){
	headers={"Host":"localhost"};
}else{
	var host=domain.replace("http://","");
	host=host.replace("https://","");
	headers={"Host":host};
}
console.log(headers);
function connect(event) {
    username = document.querySelector('#sender').value.trim();
    phoneVal = document.querySelector('#phone').value.trim();
    targetVal = document.querySelector('#target').value.trim();
    if(username) {
        usernamePage.classList.add('hidden');
        chatPage.classList.remove('hidden');
        var socket = new SockJS(chatDomain+'/ws');
        stompClient = Stomp.over(socket);
        stompClient.connect(headers, function onConnected() {
            // Subscribe to the Public Topic
            stompClient.subscribe('/topic/admin', onMessageReceived);
			stompClient.subscribe("/topic/public/admin", onMessageReceived);
            // Tell your username to the server
            stompClient.send("/app/chat.addUser/admin",
                {},
                JSON.stringify({sender: username, type: 'JOIN',
				fullname:fullname
					,target:targetVal,phone:phoneVal})
            )

            connectingElement.classList.add('hidden');
        }, function onError(error) {
            connectingElement.textContent = 'Could not connect to WebSocket server. Please refresh this page to try again!';
            connectingElement.style.color = 'red';
        });
    }
    event.preventDefault();
}

function display(message) {
    var messageElement = document.createElement('li');
    if(message.type === 'CHAT') {
        messageElement.classList.add('chat-message');
        var avatarElement = document.createElement('i');
        var avatarText = document.createTextNode(message.sender[0]);
        avatarElement.appendChild(avatarText);
        avatarElement.style['background-color'] = getAvatarColor(message.sender);
        messageElement.appendChild(avatarElement);

        var usernameElement = document.createElement('span');
        var usernameText = document.createTextNode(message.fullname);
        usernameElement.appendChild(usernameText);
        messageElement.appendChild(usernameElement);
		var textElement = document.createElement('p');
		var messageText = document.createTextNode(message.content);
		textElement.appendChild(messageText);

		messageElement.appendChild(textElement);
		var clone = messageElement.cloneNode(true);
		//alert(senderId+" / "+userMap[senderId]);
		userMap[senderId].appendChild(clone);

		messageArea.appendChild(messageElement);
		messageArea.scrollTop = messageArea.scrollHeight;
			

    }
}
usernameForm.addEventListener('submit', connect, true);

messageForm.addEventListener('submit', function(){
		const data={sender: username, type: 'CHAT',target:senderId,phone:phoneVal,
										fullname:fullname,
				            content: messageInput.value,
				};
	   stompClient.send("/app/receiver/"+data.target,
                {},
                JSON.stringify(data)
            );
		display(data);
}, true)